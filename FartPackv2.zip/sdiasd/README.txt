FART SOUND PACK - Minecraft Java 1.21.11

1. Replace:
   assets/troll/sounds/fart.ogg
   with your own OGG file. KEEP THE NAME fart.ogg

2. Put this ZIP directly in:
   .minecraft/resourcepacks/

3. Enable the pack in Minecraft.

4. Test:
   /playsound troll:fart master @s ~ ~ ~ 1 1

Server-console / all players:
   /execute as @a at @s run playsound troll:fart master @s ~ ~ ~ 1 1
